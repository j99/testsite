(function() {
   console.log("test");
})();